
	AAREADME File for Imaging Node Local Data Dictionaries

You have just downloaded a discipline or mission dictionary produced
by the PDS Imaging Node.  This dictionary consists of several files.
The following list is a generic list for all Imaging Node dictionary
distribution packages.  In the following sample filenames, "DDNS"
should be replaced with the dictionary's namespace id, in uppercase
characters, and nnnn should be replaced with the dictionary's four
digit version id.  So, for example, for a "Display" dictionary with
namespace "disp" and version_id of 1.0.0.4, the file shown as 
"PDS4_DDNS_nnnn.xsd" would actually be named "PDS4_DISP_1004.xsd".

PDS4_DDNS_nnnn.xsd - the XML schema file containing the dictionary
PDS4_DDNS_nnnn.sch - the Schematron validation file for the dictionary
PDS4_DDNS_nnnn.xml - the PDS4 XML label for the dictionary product
PDS4_<dictname>_nnnn_yyyymmddhhmmss.xml - the PDS4 XML Ingest_LDD file
                     used to create the dictionary 

PDS4_DDNS_nnnn.html - the HTML documentation file for the dictionary

catalog_nnnn.xml - an XML catalog file providing sample namespace
                     mappings for the dictionary and PDS common
                     namespaces
PDS4_DDNS_nnnn.xpr - a project file that can be used to load the
                     dictionary and its associated files into Oxygen 
.project - a project file that can be used to load the dictionary and
                     its associated files into Eclipse

PDS4_PDS_1000.xsd - a copy of the PDS common dictionary schema file
PDS4_PDS_1000.sch - a copy of the PDS common dictionary Schematron
                     validation file
PDS4_PDS_1000.xml - a copy of the PDS common dictionary PDS4 XML label

sample_*.xml - sample product labels demonstrating how to use the
                     dictionary and for validation testing purposes
sample_*.img/tab/other - sample data products
