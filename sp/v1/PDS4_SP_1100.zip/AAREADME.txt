*******************************************************************************

                     AAREADME File for Spectra Dictionary

*******************************************************************************

 QUICKSTART: Before using this dictionary, you must edit one line in the XML
 catalog file, named "catalog_1100.xml".  Open this file in any text editor.

 Find the line in the file that begins with "<group xml:base=".  Edit this line
 to point to the directory on your computer containing the dictionary you have
 just downloaded.  For operating systems based on Unix (Linux, MacOSX), the
 file path should have a form similar to the following:

     file:///Users/myusername/mydirectorypath    (MacOSX)
 or
     file:///home/myusername/mydirectorypath     (Unix, Linux)

 For PC based operating systems, the file path should have the form:

     file:///S:myusernamemydirectorypath

 You should now be able to view and test this dictionary by opening the file
 "PDS4_SP_1100.xpr" as a project in Oxygen, or by opening the file ".project"
 as a project in Eclipse.  (Note, the latter doesn't work yet.)




*******************************************************************************

 You have just downloaded the Spectra discipline dictionary produced by the PDS
 Imaging Node.  This dictionary consists of several files.  The following list
 describes all the files that have been included in this dictionary.

 PDS4_SP_1100.xsd             - the XML schema file containing the dictionary
 PDS4_SP_1100.sch             - the Schematron validation file for the
                                dictionary
 PDS4_SP_1100.xml             - the PDS4 XML label for the dictionary product
 PDS4_Spectra_1100_20131111135132.xml - the PDS4 XML Ingest_LDD file used to
                                create the dictionary
 PDS4_Spectra_1100_20131111135132_sch.xml - a prototypical "extended" Ingest_LDD
                                file containing Schematron rules, used to create 
                                the dictionary

 PDS4_SP_1100.html            - the HTML documentation file for the dictionary

 catalog_1100.xml             - an OASIS XML catalog file providing the
                                mappings between the local and PDS common
                                namespaces and their corresponding schema files
 PDS4_SP_1100.xpr             - a project file that can be used to laod the
                                dictionary and its associated files into Oxygen
 .project                     - a project file that can be used to load the
                                dictionary and its associated files into
                                Eclipse (not yet functional)

 PDS4_PDS_1100.xsd            - a copy of the PDS common dictonary schema file
 PDS4_PDS_1100.sch            - a copy of the PDS common dictionary Schematron
                                validation file
 PDS4_PDS_1100.xml            - a copy of the PDS common dictionary PDS4 XML
                                label

 PDS4_DISP_1100.xsd           - a copy of the PDS Display discipline dictionary
                                schema file, used by some of the sample products
 PDS4_DISP_1100.sch           - a copy of the PDS Display discipline dictionary
                                Schematron validation file
 PDS4_DISP_1100.xml           - a copy of the PDS Display discipline dictionary
                                PDS4 XML label

 sample_comet_2d_spectrum.lbl - PDS3 label for product described by
                                sample_comet_2d_spectrum.xml
 sample_comet_2d_spectrum.xml - PDS4 label demonstrating use of
                                Axis_Uniformly_Sampled class.
 sample_qube_5_bands.lab      - ISIS label for product described by
                                sample_qube_5_bands.xml
 sample_qube_5_bands.lbl      - PDS3 label for product described by
                                sample_qube_5_bands.xml
 sample_qube_5_bands.xml      - PDS4 label demonstrating use of Axis_Bin_Set
                                class, with only 5 bands.
 sample_qube_408_bands.lbl    - PDS3 label for product described by
                                sample_qube_408_bands.xml
 sample_qube_408_bands.xml    - PDS4 label demonstrating use of Axis_Bin_Set
                                class, taking advantage of the "xs:any"
                                structure to add extra attributes to the Bin
                                class, and employing an XML include file to
                                handle the description of the 408 bands.
 sample_qube_408_bands_include.xml - PDS4 "include" file, containing the
                                Axis_Bin_Set description for the 408 banded
                                qube.
 sample_include_408.xml       - Prototypical PDS4 label for include file.
                                WARNING: This is only a proof-of-concept and is
                                not a valid product type!  See future updates
                                to the PDS4 Information Model to determine how
                                include files should be labeled.
 PDS4_GONIMS_1100.xsd         - PDS4 mission dictionary for
                                sample_qube_408_bands.xml sample product.
